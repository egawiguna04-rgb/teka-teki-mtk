#!/usr/bin/env python3
"""Teka-Teki MTK: game teka-teki matematika sederhana (versi terminal)."""

import random

TOTAL = 10


def pola_tambah():
    a = random.randint(2, 20)
    d = random.choice([2, 3, 4, 5, 6, 7, 9, -2, -3])
    if d < 0:
        a += 30
    deret = [a + d * i for i in range(6)]
    hilang = random.randint(1, 4)
    jawab = deret[hilang]
    teks = [str(x) for x in deret]
    teks[hilang] = "?"
    return {
        "jenis": "Pola bilangan",
        "teks": ", ".join(teks),
        "jawab": jawab,
        "petunjuk": "Lihat selisih dua bilangan yang bersebelahan. Selisihnya selalu sama.",
    }


def pola_kali():
    a = random.randint(1, 5)
    r = random.choice([2, 3])
    deret = [a * r**i for i in range(5)]
    hilang = random.randint(1, 3)
    jawab = deret[hilang]
    teks = [str(x) for x in deret]
    teks[hilang] = "?"
    return {
        "jenis": "Pola bilangan",
        "teks": ", ".join(teks),
        "jawab": jawab,
        "petunjuk": "Setiap bilangan dikali bilangan yang sama untuk mendapat bilangan berikutnya.",
    }


def isi_hilang():
    jenis = "Isi yang hilang"
    k = random.randint(0, 3)
    if k == 0:
        a, b = random.randint(6, 60), random.randint(3, 40)
        return {"jenis": jenis, "teks": f"{a} + ? = {a + b}", "jawab": b,
                "petunjuk": f"Kurangi {a + b} dengan {a}."}
    if k == 1:
        a, b = random.randint(6, 60), random.randint(3, 40)
        return {"jenis": jenis, "teks": f"? − {b} = {a}", "jawab": a + b,
                "petunjuk": "Lawan dari mengurangi adalah menambah."}
    if k == 2:
        x, y = random.randint(3, 12), random.randint(3, 12)
        return {"jenis": jenis, "teks": f"{x} × ? = {x * y}", "jawab": y,
                "petunjuk": f"Bagi {x * y} dengan {x}."}
    p, q = random.randint(3, 12), random.randint(3, 12)
    return {"jenis": jenis, "teks": f"? ÷ {p} = {q}", "jawab": p * q,
            "petunjuk": "Lawan dari membagi adalah mengalikan."}


def aku_bilangan():
    x, m, c = random.randint(2, 15), random.randint(2, 5), random.randint(2, 12)
    return {
        "jenis": "Aku bilangan berapa?",
        "teks": f"Jika aku dikali {m} lalu ditambah {c}, hasilnya {x * m + c}. Aku bilangan berapa?",
        "jawab": x,
        "petunjuk": f"Balik langkahnya: kurangi {c} dulu, lalu bagi {m}.",
    }


def jumlah_selisih():
    besar = random.randint(10, 40)
    kecil = random.randint(2, besar - 2)
    return {
        "jenis": "Dua bilangan",
        "teks": (f"Dua bilangan berjumlah {besar + kecil} dan selisihnya {besar - kecil}. "
                 "Berapa bilangan yang lebih besar?"),
        "jawab": besar,
        "petunjuk": "Bilangan besar = (jumlah + selisih) ÷ 2.",
    }


def keliling_persegi():
    s = random.randint(3, 20)
    return {
        "jenis": "Bangun datar",
        "teks": f"Keliling sebuah persegi {4 * s} cm. Berapa panjang satu sisinya (cm)?",
        "jawab": s,
        "petunjuk": "Persegi punya 4 sisi sama panjang. Bagi kelilingnya dengan 4.",
    }


GENERATOR = [pola_tambah, pola_kali, isi_hilang, aku_bilangan, jumlah_selisih, keliling_persegi]


def tanya(nomor, skor):
    """Tampilkan satu soal. Kembalikan (benar, poin)."""
    soal = random.choice(GENERATOR)()
    print(f"\nSoal {nomor} dari {TOTAL}   |   Skor: {skor}")
    print(f"[{soal['jenis']}]")
    print(f"  {soal['teks']}\n")

    pakai_petunjuk = False
    while True:
        masukan = input("Jawabanmu (ketik p untuk petunjuk): ").strip().lower()
        if masukan == "p":
            pakai_petunjuk = True
            print(f"Petunjuk: {soal['petunjuk']} (poin jadi 5)")
            continue
        try:
            jawaban = int(masukan)
        except ValueError:
            print("Tulis jawaban berupa bilangan bulat, ya.")
            continue
        break

    if jawaban == soal["jawab"]:
        poin = 5 if pakai_petunjuk else 10
        print(f"Benar! +{poin} poin.")
        return True, poin
    print(f"Belum tepat. Jawaban yang benar: {soal['jawab']}.")
    return False, 0


def judul_hasil(benar):
    persen = benar / TOTAL
    if persen == 1:
        return "Sempurna!"
    if persen >= 0.7:
        return "Hebat!"
    if persen >= 0.4:
        return "Lumayan, terus berlatih!"
    return "Ayo coba lagi!"


def main_sekali():
    skor = 0
    benar = 0
    for nomor in range(1, TOTAL + 1):
        ok, poin = tanya(nomor, skor)
        skor += poin
        benar += ok
    print("\n" + "=" * 36)
    print(judul_hasil(benar))
    print(f"Skor: {skor} dari maksimal {TOTAL * 10}")
    print(f"Benar: {benar} dari {TOTAL} soal")
    print("=" * 36)


def main():
    print("=== Teka-Teki MTK ===")
    print(f"Selesaikan {TOTAL} soal. Benar = 10 poin, pakai petunjuk = 5 poin.")
    try:
        while True:
            main_sekali()
            lagi = input("\nMain lagi? (y/t): ").strip().lower()
            if lagi != "y":
                break
    except (KeyboardInterrupt, EOFError):
        pass
    print("\nTerima kasih sudah bermain!")


if __name__ == "__main__":
    main()
