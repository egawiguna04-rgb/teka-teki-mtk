import unittest

import teka_teki_mtk as t


class TesGenerator(unittest.TestCase):
    def test_semua_soal_valid(self):
        for gen in t.GENERATOR:
            for _ in range(200):
                soal = gen()
                self.assertIsInstance(soal["jawab"], int)
                self.assertGreater(soal["jawab"], 0)
                self.assertTrue(soal["teks"])
                self.assertTrue(soal["petunjuk"])

    def test_judul_hasil(self):
        self.assertEqual(t.judul_hasil(10), "Sempurna!")
        self.assertEqual(t.judul_hasil(7), "Hebat!")
        self.assertEqual(t.judul_hasil(4), "Lumayan, terus berlatih!")
        self.assertEqual(t.judul_hasil(0), "Ayo coba lagi!")


if __name__ == "__main__":
    unittest.main()
