# Teka-Teki MTK

Game teka-teki matematika sederhana untuk terminal. Ada 10 soal acak setiap main:
pola bilangan, angka yang hilang, "Aku bilangan berapa?", jumlah dan selisih,
serta keliling persegi.

## Cara main

Butuh Python 3.10 atau lebih baru. Tidak ada pustaka tambahan.

```bash
python3 teka_teki_mtk.py
```

- Jawaban benar dapat 10 poin.
- Ketik `p` untuk petunjuk. Poin soal itu menjadi 5.
- Skor maksimal 100.

## Menjalankan tes

```bash
python3 -m unittest -v
```

## Lisensi

MIT. Lihat berkas `LICENSE`.
